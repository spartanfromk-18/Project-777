import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { analyzeMessageLocally } from './src/utils/scamEngine.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '10mb' }));

  // API endpoint for ScamShield message verification
  app.post('/api/check', (req, res) => {
    try {
      const { text } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: 'Message text is required for analysis.' });
      }

      // Perform message analysis
      const result = analyzeMessageLocally(text);
      return res.json(result);
    } catch (err: any) {
      console.error('Scam analysis error:', err);
      return res.status(500).json({ error: err.message || 'Internal analysis error' });
    }
  });

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    return res.json({ status: 'ok', service: 'ScamShield Verification API' });
  });

  // Direct ZIP download route
  app.get('/ScamShield-Frontend.zip', (_req, res) => {
    const zipPath = path.resolve(__dirname, 'public', 'ScamShield-Frontend.zip');
    res.download(zipPath, 'ScamShield-Frontend.zip');
  });

  // In development, attach Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve built static assets
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ScamShield server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
