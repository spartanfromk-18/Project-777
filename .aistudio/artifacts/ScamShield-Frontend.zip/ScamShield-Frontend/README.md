# ScamShield — Complete Frontend Source & Localhost Package

> **Is this message a scam? Find out in 10 seconds.**
> ScamShield is a privacy-first web application designed to protect families in India from electricity disconnection threats, fake bank KYC/PAN blocks, work-from-home tasks, digital arrests, and lottery frauds.

---

## What This Package Contains

This standalone ZIP contains the full, self-contained frontend application source code, offline rule engine, and production-ready distribution.

- **Zero External Dependencies**: Works 100% offline in Local Mode.
- **Zero Secrets / API Keys**: No `.env` files, no credentials, no tracking.
- **Fully Responsive**: Mobile-first design (360px to 1440px+).

---

## Exact File List

```
ScamShield-Frontend/
├── README.md                          # Complete setup and offline guide
├── index.html                         # Entry HTML with Readex Pro font & meta tags
├── package.json                       # Dependencies & scripts
├── tsconfig.json                      # TypeScript configuration
├── vite.config.ts                     # Vite build & bundler configuration
├── server.ts                          # Express backend with /api/check route
├── dist/                              # Pre-built production standalone bundle
│   ├── index.html                     # Compiled HTML
│   └── assets/                        # Compiled CSS and JS bundles
└── src/
    ├── App.tsx                        # Main landing page layout (all sections)
    ├── index.css                      # Tailwind CSS & custom design palette tokens
    ├── main.tsx                       # React DOM entry point
    ├── components/
    │   ├── Navbar.tsx                 # Sticky pill navigation with working anchors
    │   ├── Hero.tsx                   # Bold headline, subheadline, CTAs
    │   ├── PhoneMockup.tsx            # Realistic scam message + red SCAM card
    │   ├── Checker.tsx                # Live checker with 6 golden cases
    │   ├── HowItWorks.tsx             # 3-step workflow
    │   ├── ExampleVerdicts.tsx        # Comparative SCAM vs LOOKS_SAFE verdicts
    │   ├── ScamAutopsySection.tsx     # Breakdown of scam traps & family warnings
    │   ├── PrivacySection.tsx         # Honest dual-mode privacy documentation
    │   ├── SafetySection.tsx          # 5 golden rules + 1930 emergency helpline
    │   ├── FaqSection.tsx             # Grade-6 level common questions
    │   └── Footer.tsx                 # Community footer with GitHub link
    ├── data/
    │   ├── goldenCases.ts             # 6 Golden Cases + authentication OTP control
    │   └── landingData.ts             # Constants and metadata
    └── utils/
        └── scamEngine.ts              # Local heuristic rule engine (100% offline)
```

---

## How to Run Locally After Unzipping (Step-by-Step)

### Option 1: Standard Node.js / Vite Dev Server (Recommended)

1. **Unzip the archive**:
   Extract `ScamShield-Frontend.zip` into any folder on your computer.

2. **Open your terminal** and navigate into the extracted folder:
   ```bash
   cd ScamShield-Frontend
   ```

3. **Install dependencies**:
   ```bash
   npm install
   ```

4. **Start the local server**:
   ```bash
   npm run dev
   ```

5. **Open your browser**:
   Visit [http://localhost:3000](http://localhost:3000). The app will load with the live checker, sample chips, phone mockup, and all sections.

---

### Option 2: Run the Standalone Production Build (Zero Build Needed)

If you have Node.js installed and want to preview the pre-compiled distribution in `dist/`:

```bash
# Using npx serve:
npx serve dist -l 3000

# Or using Python's built-in HTTP server:
cd dist && python3 -m http.server 3000
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Verification & Offline Functionality

- **Hero & Navigation**: All anchor links (`How it works`, `Try a sample`, `Safety`, `FAQ`) scroll to the respective sections.
- **Live Checker**:
  - Click any of the 6 Golden Case chips (e.g. `⚡ Bijli Bill`, `🏦 Bank KYC`, `🛡️ Service OTP`).
  - Click **"CHECK MESSAGE"**.
  - The local rule engine evaluates the text within milliseconds and renders the verdict card, detected red flags, scam autopsy, and copyable WhatsApp warning.
- **Copy for Family**: Click **"Copy Warning for Family"** to copy the formatted Hinglish alert note.
- **100% Offline**: In Local Mode, no data leaves your browser. All analysis happens entirely on your machine.
